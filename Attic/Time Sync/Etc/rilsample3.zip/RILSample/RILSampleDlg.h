// RILSampleDlg.h : header file
//

#pragma once
#include "afxwin.h"

#define X_OFFSET					10
#define Y_OFFSET					10
#define MIN_TELPHONE_NUMBER_LEN		10

typedef struct __DEVCAPS_TYPE_TAG__
{
	DWORD	dwType;
	LPCTSTR	lpszText;
}DEVCAPS_TYPE, *PDEVCAPS_TYPE;

// CRILSampleDlg dialog
class CRILSampleDlg : public CDialog
{
// Construction
public:
	CRILSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_RILSAMPLE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

public:
	void AddLog(LPCTSTR lpszLog,BOOL bAppend = FALSE);
	void GetDevCapsResult(const void* pData,CString& strResult,CString& strInfo);

public:
	HRESULT GetDevCapsResult() const
	{
		return m_hDevCapsResult;
	}

private:
	HRIL		m_hRIL;
	DWORD		m_dwDevCapType;
	HRESULT		m_hDevCapsResult;

private:
	void AddCommandsToCombo(CComboBox* pCombo);

// Implementation
protected:
	HICON		m_hIcon;
	CEdit		m_wndData;
	CComboBox	m_wndCapsType;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
	afx_msg void OnDestroy();
	afx_msg void OnMenuAbout();
	afx_msg void OnCbnSelendokCapstype();

	DECLARE_MESSAGE_MAP()
};