// RILSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RILSample.h"
#include "RILSampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

DEVCAPS_TYPE	_sDevCapsTypes[]	= 
{
	{RIL_CAPSTYPE_GPRSCLASS,TEXT("GPRS Class")},
	{RIL_CAPSTYPE_CALLMGTCMDS,TEXT("Call Management Commands")},
	{RIL_CAPSTYPE_GPRSMOSMS,TEXT("Services for SMS")},
	{RIL_CAPSTYPE_SIMSUPPORT,TEXT("Sim Support")},
};

void CALLBACK ResultCallback(DWORD dwCode,HRESULT hrCmdID,const void *lpData,DWORD cbData,DWORD dwParam)
{
	CRILSampleDlg*	pClass	= (CRILSampleDlg*)dwParam;
	CString			strData;

	strData.Format(TEXT("ResultCallback: Code: %X\r\n"),dwCode);

	if(!pClass)
		return;

	CString			strInfo(TEXT(""));

	if(pClass->GetDevCapsResult() == hrCmdID && pClass)
	{
		pClass->GetDevCapsResult(lpData,strData,strInfo);
	}

	CString			strMessage	= strData;

	strMessage	+= TEXT("\r\n");
	strMessage	+= strInfo;

	if(pClass)
		pClass->AddLog(strMessage);
}

void CALLBACK NotifyCallback(DWORD dwCode,const void *lpData,DWORD cbData, DWORD dwParam)
{
	CRILSampleDlg*	pClass	= (CRILSampleDlg*)dwParam;
	DWORD			dwClass	= (dwCode & RIL_NCLASS_ALL);
	CString			strData;
	CString			strParam(TEXT(""));

	strData.Format(TEXT("NotifyCallback: Code: %X\r\n"),dwClass);

	switch(dwClass)
	{
		case RIL_NCLASS_FUNCRESULT:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_FUNCRESULT"));	break;
		case RIL_NCLASS_CALLCTRL:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_CALLCTRL"));		break;
		case RIL_NCLASS_MESSAGE:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_MESSAGE"));		break;
		case RIL_NCLASS_NETWORK:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_NETWORK"));		break;
		case RIL_NCLASS_SUPSERVICE:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_SUPSERVICE"));	break;
		case RIL_NCLASS_PHONEBOOK:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_PHONEBOOK"));	break;
		case RIL_NCLASS_SIMTOOLKIT:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_SIMTOOLKIT"));	break;
		case RIL_NCLASS_MISC:			strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_MISC"));			break;
		case RIL_NCLASS_RADIOSTATE:		strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_RADIOSTATE"));	break;
		case RIL_NCLASS_NDIS:			strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_NDIS"));			break;
		case RIL_NCLASS_DEVSPECIFIC:	strData.Format(TEXT("%s"),TEXT("RIL_NCLASS_DEVSPECIFIC"));	break;
	}

	switch(dwCode)
	{
		case RIL_NOTIFY_RADIOEQUIPMENTSTATECHANGED:
		{
			RILEQUIPMENTSTATE*	pState	= (RILEQUIPMENTSTATE*)lpData;

			strParam.Format(TEXT("\tRadio Support: %X\r\n\tEquipment State: %X\r\n\tReady State: %X"),
						   pState->dwRadioSupport,pState->dwEqState,pState->dwReadyState);

			break;
		}
		case RIL_NOTIFY_RADIOPRESENCECHANGED:
		{
			DWORD	dwPresence	= (DWORD)*((DWORD*)lpData);

			switch(dwPresence)
			{
				case RIL_RADIOPRESENCE_NOTPRESENT:	strParam.Format(TEXT("\tRadio module is not present"));		break;
				case RIL_RADIOPRESENCE_PRESENT:		strParam.Format(TEXT("\tRadio module is present"));			break;
				default:							strParam.Format(TEXT("\tUnknown value: %X"),dwPresence);	break;
			}

			break;
		}
		case RIL_NOTIFY_MESSAGE:
		{
			RILMESSAGE*	pMessage	= (RILMESSAGE*)lpData;

			switch(pMessage->dwType)
			{
				case RIL_MSGTYPE_IN_DELIVER:
				{
					strParam.Format(TEXT("\tMessage From: %s\r\n\tTime: %02d-%02d-%02d %02d:%02d:%02d\r\n\tCode: %X"),
									pMessage->msgInDeliver.raOrigAddress.wszAddress,
									pMessage->msgInDeliver.stSCReceiveTime.wMonth,
									pMessage->msgInDeliver.stSCReceiveTime.wDay,
									pMessage->msgInDeliver.stSCReceiveTime.wYear,
									pMessage->msgInDeliver.stSCReceiveTime.wHour,
									pMessage->msgInDeliver.stSCReceiveTime.wMinute,
									pMessage->msgInDeliver.stSCReceiveTime.wSecond,
									dwCode);

					break;
				}
			}
		}
		case RIL_NOTIFY_CALLPROGRESSINFO:
		{
			RILCALLINFO*	pInfo	= (RILCALLINFO*)lpData;

			strParam.Format(TEXT("\tCall From: %s"),pInfo->raAddress.wszAddress);

			break;
		}
		case RIL_NOTIFY_CALLERID:
		{
			RILREMOTEPARTYINFO*	pInfo	= (RILREMOTEPARTYINFO*)lpData;

			break;
		}
		case RIL_NOTIFY_SUPSERVICEDATA:
		{
			LPRILSUPSERVICEDATA	pData	= (LPRILSUPSERVICEDATA)lpData;

			strParam.Format(TEXT("\tRIL_NOTIFY_SUPSERVICEDATA:%d, %d, %d"),pData->cbSize,pData->dwParams,pData->dwStatus);

			break;
		}
		case RIL_NOTIFY_UNSOLICITEDSS:
		{
			strParam.Format(TEXT("\tRIL_NOTIFY_UNSOLICITEDSS"));

			break;
		}
		case RIL_NOTIFY_DIALEDID:
		{
			strParam.Format(TEXT("\tRIL_NOTIFY_DIALEDID"));

			break;
		}
		case RIL_NOTIFY_CALLWAITING:
		{
			strParam.Format(TEXT("\tRIL_NOTIFY_CALLWAITING"));

			break;
		}
		case RIL_NOTIFY_INTERMEDIATESS:
		{
			strParam.Format(TEXT("\tRIL_NOTIFY_INTERMEDIATESS"));

			break;
		}
		default:
		{
			strParam.Format(TEXT("\tParam %x"),dwCode);

			break;
		}
	}

	CString		strMessage	= strData;
	
	if(strParam.GetLength() > 0)
	{
		strMessage	+= TEXT("\r\n");
		strMessage	+= strParam;
	}

	/*if(pClass)
		pClass->AddLog(strMessage);*/
}

// CRILSampleDlg dialog

CRILSampleDlg::CRILSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRILSampleDlg::IDD, pParent)
{
	m_hIcon 				= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hRIL					= NULL;
	m_hDevCapsResult		= NULL;
	m_dwDevCapType			= 0;
}

void CRILSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DATA, m_wndData);
	DDX_Control(pDX, IDC_CAPSTYPE, m_wndCapsType);
}

BEGIN_MESSAGE_MAP(CRILSampleDlg, CDialog)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_COMMAND(ID_MENU_ABOUT, &CRILSampleDlg::OnMenuAbout)
	ON_CBN_SELENDOK(IDC_CAPSTYPE, &CRILSampleDlg::OnCbnSelendokCapstype)
END_MESSAGE_MAP()

// CRILSampleDlg message handlers

void CRILSampleDlg::AddLog(LPCTSTR lpszLog,BOOL bAppend /* = FALSE */)
{
	CString		strText;

	if(bAppend)
	{
		m_wndData.GetWindowText(strText);

		if(strText.GetLength() > 0)
			strText	+=	TEXT("\r\n");

		strText	+= lpszLog;
	}
	else
	{
		strText	= lpszLog;
	}

	m_wndData.SetWindowText(strText);
}


BOOL CRILSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	SHMENUBARINFO info; 
	
	info.cbSize			= sizeof(info); 
	info.hwndParent		= m_hWnd; 
	info.dwFlags		= SHCMBF_HMENU | SHCMBF_HIDESIPBUTTON; 
	info.nToolBarId		= IDR_MENU; 
	info.hInstRes		= ::AfxGetInstanceHandle(); 
	info.nBmpId			= 0; 
	info.cBmpImages		= 0; 
	
	SHCreateMenuBar(&info);

	HRESULT	hr = RIL_Initialize(1,ResultCallback,NotifyCallback,
								RIL_NCLASS_ALL,(DWORD)this,&m_hRIL);

	if(FAILED(hr))
	{
		m_hRIL	= NULL;

		AfxMessageBox(TEXT("Failed to initialize RIL"));

		m_wndCapsType.EnableWindow(FALSE);
		m_wndData.EnableWindow(FALSE);
	}
	else
	{
		AddCommandsToCombo(&m_wndCapsType);
		OnCbnSelendokCapstype();
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRILSampleDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType,cx,cy);

	if(m_wndData.GetSafeHwnd() && m_wndCapsType.GetSafeHwnd())
	{
		CRect	rc;

		m_wndCapsType.GetWindowRect(&rc);

		m_wndCapsType.SetWindowPos(NULL,DRA::SCALEX(X_OFFSET),DRA::SCALEY(Y_OFFSET),
								   DRA::SCALEX(cx - X_OFFSET * 2),DRA::SCALEY(rc.Height()),SWP_NOZORDER);

		m_wndData.SetWindowPos(NULL,DRA::SCALEX(X_OFFSET),DRA::SCALEY((Y_OFFSET* 2) + rc.Height()),
							   DRA::SCALEX(cx - X_OFFSET * 2),DRA::SCALEY(cy - (X_OFFSET * 3) - rc.Height()),
							   SWP_NOZORDER);
	}
}

void CRILSampleDlg::OnDestroy()
{
	if(m_hRIL)
		RIL_Deinitialize(m_hRIL);

	CDialog::OnDestroy();
}

void CRILSampleDlg::OnMenuAbout()
{
	AfxMessageBox(TEXT("RIL Sample\r\nKrishnaraj Varma\r\nhttp://www.krvarma.com\r\nvarma@krvarma.com"));
}

void CRILSampleDlg::AddCommandsToCombo(CComboBox* pCombo)
{
	int		nCount	= sizeof(_sDevCapsTypes) / sizeof(_sDevCapsTypes[0]);
	int		nItem	= 0;

	for(int nIndex=0; nIndex<nCount; ++nIndex)
	{
		nItem	= pCombo->AddString(_sDevCapsTypes[nIndex].lpszText);

		pCombo->SetItemData(nItem,_sDevCapsTypes[nIndex].dwType);
	}

	pCombo->SetCurSel(0);
}

void CRILSampleDlg::GetDevCapsResult(const void* pData,CString& strData,CString& strInfo)
{
	switch(m_dwDevCapType)
	{
		case RIL_CAPSTYPE_GPRSCLASS:
		{
			DWORD	dwFlags	= (DWORD)(*((DWORD*)pData));

			strData.Format(TEXT("GPRS Class:"));

			if(dwFlags & RIL_GPRSCLASS_GSMANDGPRS)
				strInfo	+= TEXT("\tRIL_GPRSCLASS_GSMANDGPRS");
			else if(dwFlags & RIL_GPRSCLASS_GSMORGPRS)
				strInfo	+= TEXT("\tRIL_GPRSCLASS_GSMORGPRS");
			else if(dwFlags & RIL_GPRSCLASS_GSMORGPRS_EXCLUSIVE)
				strInfo	+= TEXT("\tRIL_GPRSCLASS_GSMORGPRS_EXCLUSIVE");
			else if(dwFlags & RIL_GPRSCLASS_GPRSONLY)
				strInfo	+= TEXT("\tRIL_GPRSCLASS_GPRSONLY");
			else if(dwFlags & RIL_GPRSCLASS_GSMONLY)
				strInfo	+= TEXT("\tRIL_GPRSCLASS_GSMONLY");
			else
				strInfo	+= TEXT("\tUnknown");

			break;
		}
		case RIL_CAPSTYPE_CALLMGTCMDS:
		{
			DWORD	dwFlags	= (DWORD)(*((DWORD*)pData));

			strData.Format(TEXT("Call Management Commands:"));

			if(dwFlags & RIL_CAPS_CALLCMD_RELEASEHELD)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_RELEASEHELD");
			
			if(dwFlags & RIL_CAPS_CALLCMD_RELEASEACTIVE_ACCEPTHELD)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_RELEASEACTIVE_ACCEPTHELD");
			
			if(dwFlags & RIL_CAPS_CALLCMD_RELEASECALL)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_RELEASECALL");

			if(dwFlags & RIL_CAPS_CALLCMD_HOLDACTIVE_ACCEPTHELD )
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_HOLDACTIVE_ACCEPTHELD");

			if(dwFlags & RIL_CAPS_CALLCMD_HOLDALLBUTONE)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_HOLDALLBUTONE");
			
			if(dwFlags & RIL_CAPS_CALLCMD_ADDHELDTOCONF)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_ADDHELDTOCONF");

			if(dwFlags & RIL_CAPS_CALLCMD_ADDHELDTOCONF_DISCONNECT)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_ADDHELDTOCONF_DISCONNECT");

			if(dwFlags & RIL_CAPS_CALLCMD_INVOKECCBS)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_CALLCMD_INVOKECCBS");

			break;
		}
		case RIL_CAPSTYPE_GPRSMOSMS:
		{
			DWORD	dwFlags	= (DWORD)(*((DWORD*)pData));

			strData.Format(TEXT("Call Management Commands:"));

			if(dwFlags & RIL_MOSMSSERVICE_CIRCUIT)
				strInfo	+= TEXT("\r\n\tRIL_MOSMSSERVICE_CIRCUIT");
			
			if(dwFlags & RIL_MOSMSSERVICE_GPRS)
				strInfo	+= TEXT("\r\n\tRIL_MOSMSSERVICE_GPRS");
			
			if(dwFlags & RIL_MOSMSSERVICE_CIRCUITPREFERRED)
				strInfo	+= TEXT("\r\n\tRIL_MOSMSSERVICE_CIRCUITPREFERRED");

			if(dwFlags & RIL_MOSMSSERVICE_GPRSPREFERRED)
				strInfo	+= TEXT("\r\n\tRIL_MOSMSSERVICE_GPRSPREFERRED");

			break;
		}
		case RIL_CAPSTYPE_SIMSUPPORT:
		{
			DWORD	dwFlags	= (DWORD)(*((DWORD*)pData));

			strData.Format(TEXT("Sim Support:"));

			if(dwFlags == RIL_CAPS_SIM_NONE)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_SIM_NONE");
			else if(dwFlags == RIL_CAPS_SIM_BASIC)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_SIM_BASIC");
			
			break;
		}
		case RIL_CAPSTYPE_EQUIPMENTSTATES:
		{
			DWORD	dwFlags	= (DWORD)(*((DWORD*)pData));

			strData.Format(TEXT("Equipment State:"));

			if(dwFlags & RIL_CAPS_EQSTATE_MINIMUM)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_EQSTATE_MINIMUM");

			if(dwFlags & RIL_CAPS_EQSTATE_FULL)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_EQSTATE_FULL");

			if(dwFlags & RIL_CAPS_EQSTATE_DISABLETX)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_EQSTATE_DISABLETX");

			if(dwFlags & RIL_CAPS_EQSTATE_DISABLERX)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_EQSTATE_DISABLERX");

			if(dwFlags & RIL_CAPS_EQSTATE_DISABLETXANDRX)
				strInfo	+= TEXT("\r\n\tRIL_CAPS_EQSTATE_DISABLETXANDRX");

			break;
		}
		default:
		{
			strData.Format(TEXT("Dev Caps:"));
			strInfo.Format(TEXT("\tUnknown"));
		}
	}
}
void CRILSampleDlg::OnCbnSelendokCapstype()
{
	int		nSel		= m_wndCapsType.GetCurSel();

	if(CB_ERR == nSel)
		return;

	m_dwDevCapType		= m_wndCapsType.GetItemData(nSel);
	m_hDevCapsResult	= RIL_GetDevCaps(m_hRIL,m_dwDevCapType);	
}
