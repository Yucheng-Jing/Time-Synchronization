// SignalStrengthDlg.h : header file
//

#pragma once
#include "afxwin.h"

#define TAPI_FRIENDLY_NAME		TEXT("SignalStrengthSample")

#define X_OFFSET				10
#define Y_OFFSET				10

// CSignalStrengthDlg dialog
class CSignalStrengthDlg : public CDialog
{
// Construction
public:
	CSignalStrengthDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SIGNALSTRENGTH_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

private:
	HLINEAPP				m_hLineApp;
	DWORD					m_dwDevices;
	DWORD					m_dwCellularId;
	DWORD					m_dwLowAPIVersion;
	CEdit					m_wndInfo;

private:
	long  InitializeTAPI();
	void  ShutdownTAPI();
	DWORD GetCellularLineId();
	DWORD GetSignalStrength(CString& strOperator);


	static void FAR PASCAL lineCallback(DWORD hDevice,
										DWORD dwMsg,
										DWORD dwCallbackInstance,
										DWORD dwParam1,
										DWORD dwParam2,
										DWORD dwParam3);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
	afx_msg void OnDestroy();
	afx_msg void OnMenuAbout();

	DECLARE_MESSAGE_MAP()
};
