// SignalStrengthDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SignalStrength.h"
#include "SignalStrengthDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void FAR PASCAL CSignalStrengthDlg::lineCallback(DWORD hDevice,DWORD dwMsg,DWORD dwCallbackInstance,
												 DWORD dwParam1,DWORD dwParam2,DWORD dwParam3)
{
}

// CSignalStrengthDlg dialog

CSignalStrengthDlg::CSignalStrengthDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSignalStrengthDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hLineApp			= NULL;
	m_dwDevices			= 0;
	m_dwLowAPIVersion	= 0;
	m_dwCellularId		= 0;
}

void CSignalStrengthDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_INFO, m_wndInfo);
}

BEGIN_MESSAGE_MAP(CSignalStrengthDlg, CDialog)
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_COMMAND(ID_APP_ABOUT, &CSignalStrengthDlg::OnMenuAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CSignalStrengthDlg message handlers

BOOL CSignalStrengthDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_wndInfo.SetReadOnly(TRUE);
	m_wndInfo.ModifyStyle(0,ES_MULTILINE);

	SHMENUBARINFO info; 
	
	info.cbSize			= sizeof(info); 
	info.hwndParent		= m_hWnd; 
	info.dwFlags		= SHCMBF_HMENU | SHCMBF_HIDESIPBUTTON; 
	info.nToolBarId		= IDR_MENU; 
	info.hInstRes		= ::AfxGetInstanceHandle(); 
	info.nBmpId			= 0; 
	info.cBmpImages		= 0; 
	
	SHCreateMenuBar(&info);

	if(0 == InitializeTAPI())
	{
		m_dwCellularId	= GetCellularLineId();

		CString		strSignalStrength;
		CString		strOperator;
		DWORD		dwSignalStrength	= GetSignalStrength(strOperator);

		strSignalStrength.Format(TEXT("Current Operator: %s\r\nSignal Strength: %ld%%"),
			strOperator.GetLength() > 0 ? strOperator : TEXT("No Service"),
			dwSignalStrength);

		m_wndInfo.SetWindowTextW(strSignalStrength);
	}
	
	return FALSE;  // return TRUE  unless you set the focus to a control
}

void CSignalStrengthDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType,cx,cy);

	if(m_wndInfo.GetSafeHwnd())
	{
		m_wndInfo.SetWindowPos(NULL,DRA::SCALEX(X_OFFSET),DRA::SCALEY(Y_OFFSET),
			DRA::SCALEX(cx - X_OFFSET * 2),DRA::SCALEY(cy - Y_OFFSET * 2),SWP_NOZORDER);
	}
}

void CSignalStrengthDlg::OnDestroy()
{
	ShutdownTAPI();

	CDialog::OnDestroy();
}

long CSignalStrengthDlg::InitializeTAPI()
{
	LINEINITIALIZEEXPARAMS	sLineParam;

	memset(&sLineParam,0,sizeof(LINEINITIALIZEEXPARAMS));

	sLineParam.dwTotalSize	= sizeof(LINEINITIALIZEEXPARAMS);
	sLineParam.dwOptions	= LINEINITIALIZEEXOPTION_USEHIDDENWINDOW; 

	m_dwLowAPIVersion		= TAPI_CURRENT_VERSION;

	long	lReturn	= lineInitializeEx(&m_hLineApp,
									   theApp.m_hInstance,
									   lineCallback,
									   TAPI_FRIENDLY_NAME,
									   &m_dwDevices,
									   &m_dwLowAPIVersion,
									   &sLineParam);

	return lReturn;
}

void CSignalStrengthDlg::ShutdownTAPI()
{
	if(m_hLineApp)
	{
		lineShutdown(m_hLineApp);
	}
}

DWORD CSignalStrengthDlg::GetCellularLineId()
{
	DWORD				dwReturn		= 0;
	long				lResult			= 0;
	LINEEXTENSIONID		sLineExt		= {0};
	LPLINEDEVCAPS		lpLineDevCaps	= NULL;	
	DWORD				dwAPIVersion	= TAPI_CURRENT_VERSION;
	BOOL				bContinue		= TRUE;

	for(DWORD dwLine=0; dwLine<m_dwDevices && bContinue; ++dwLine)
	{
		lResult		= lineNegotiateAPIVersion(m_hLineApp,dwLine,m_dwLowAPIVersion,TAPI_CURRENT_VERSION,&dwAPIVersion,&sLineExt);

		if(0 == lResult)
		{
			lpLineDevCaps	= (LPLINEDEVCAPS)LocalAlloc(LPTR,sizeof(LINEDEVCAPS));
			lResult			= LINEERR_STRUCTURETOOSMALL;

			lpLineDevCaps->dwTotalSize	= sizeof(LINEDEVCAPS);
			lpLineDevCaps->dwNeededSize	= sizeof(LINEDEVCAPS);

			while(LINEERR_STRUCTURETOOSMALL == lResult)
			{
				lResult	= lineGetDevCaps(m_hLineApp,dwLine,TAPI_CURRENT_VERSION,0,lpLineDevCaps);

				if(LINEERR_STRUCTURETOOSMALL == lResult || lpLineDevCaps->dwTotalSize < lpLineDevCaps->dwNeededSize)
				{
					lpLineDevCaps	= (LPLINEDEVCAPS)LocalReAlloc(lpLineDevCaps,lpLineDevCaps->dwNeededSize,LMEM_MOVEABLE);
					lResult			= LINEERR_STRUCTURETOOSMALL;

					lpLineDevCaps->dwTotalSize	= lpLineDevCaps->dwNeededSize;
				}
			}

			if(0 == lResult)
			{
				TCHAR szName[512];

				memcpy((PVOID)szName,(PVOID)((BYTE*)lpLineDevCaps + lpLineDevCaps ->dwLineNameOffset), 
					    lpLineDevCaps->dwLineNameSize);

				szName[lpLineDevCaps->dwLineNameSize]	= 0;

				if(_tcscmp(szName,CELLTSP_LINENAME_STRING) == 0)
				{
					dwReturn	= dwLine;
					bContinue	= FALSE;
				}
			}

			LocalFree((HLOCAL)lpLineDevCaps);
		}
	}

	return dwReturn;
}

DWORD CSignalStrengthDlg::GetSignalStrength(CString& strOperator)
{
	DWORD	dwSignalStrength	= 0;

	DWORD	dwMediaMode = LINEMEDIAMODE_INTERACTIVEVOICE;
	HLINE	hLine		= NULL;
	long	lReturn		= lineOpen(m_hLineApp,m_dwCellularId,&hLine,
								   TAPI_CURRENT_VERSION,0,(DWORD)this,
								   LINECALLPRIVILEGE_OWNER,dwMediaMode,0);

	if(0 != lReturn || !hLine)
	{
		CString	strError;

		strError.Format(TEXT("Error Opening the Cellular Line with: %X"),lReturn);

		MessageBox(strError,TEXT("TAPI Info"),MB_OK | MB_ICONEXCLAMATION);

		return dwSignalStrength;
	}

	LPLINEDEVSTATUS pInfo = (LPLINEDEVSTATUS)LocalAlloc(LPTR,sizeof(LINEDEVSTATUS));

	pInfo->dwTotalSize	= sizeof(LINEDEVSTATUS);
	lReturn				= LINEERR_STRUCTURETOOSMALL;

	while(LINEERR_STRUCTURETOOSMALL == lReturn)
	{
		lReturn	= lineGetLineDevStatus(hLine,pInfo);

		if(LINEERR_STRUCTURETOOSMALL == lReturn || pInfo->dwTotalSize < pInfo->dwNeededSize)
		{
			pInfo	= (LPLINEDEVSTATUS)LocalReAlloc(pInfo,pInfo->dwNeededSize,LMEM_MOVEABLE);
			lReturn	= LINEERR_STRUCTURETOOSMALL;

			pInfo->dwTotalSize	= pInfo->dwNeededSize;
		}
	}

	if(0 == lReturn)
	{
		LINEOPERATOR	sOperator;

		lineGetCurrentOperator(hLine,&sOperator);

		if(_tcslen(sOperator.lpszLongName) > 0)
		{
			strOperator.Format(TEXT("%s (%s)"),sOperator.lpszLongName,sOperator.lpszNumName);

			dwSignalStrength	= 100 * ((float)(pInfo->dwSignalLevel) / 65535.0f);
		}
	}

	LocalFree((HLOCAL)pInfo);

	return dwSignalStrength;
}

void CSignalStrengthDlg::OnMenuAbout()
{
	AfxMessageBox(TEXT("Signal Strength\r\nKrishnaraj Varma\r\nhttp://www.krvarma.com\r\nvarma@krvarma.com"));
}