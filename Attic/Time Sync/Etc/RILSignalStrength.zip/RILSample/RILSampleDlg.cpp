// RILSampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RILSample.h"
#include "RILSampleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void CALLBACK ResultCallback(DWORD dwCode,HRESULT hrCmdID,const void *lpData,DWORD cbData,DWORD dwParam)
{
	CRILSampleDlg*	pClass	= (CRILSampleDlg*)dwParam;
	CString			strData;

	strData.Format(TEXT("ResultCallback: Code: %X\r\n"),dwCode);

	if(!pClass)
		return;

	CString			strInfo(TEXT(""));

	if(pClass->GetOperatorNameResult() == hrCmdID)
	{
		RILOPERATORNAMES*	pInfo				= (RILOPERATORNAMES*)lpData;

		if(strlen(pInfo->szLongName) > 0)
		{
			pClass->SetCurrentOperator(pInfo->szLongName);

			strData	= TEXT("");
		}
	}
	else if(pClass->GetSignalQualityResult() == hrCmdID)
	{
		RILSIGNALQUALITY*	pInfo				= (RILSIGNALQUALITY*)lpData;
		int					nSignalPercentage	= 100 * (-pInfo->nSignalStrength + pInfo->nMinSignalStrength) /
												  (-pInfo->nMaxSignalStrength + pInfo->nMinSignalStrength);
		CString				strOperator			= pClass->GetCurrentOperator();

		if(strOperator.GetLength() <= 0)
		{
			nSignalPercentage	= 0;
			strOperator			= TEXT("No Service");
		}

		strData.Format(TEXT("Current Operator: %s\r\nSignal Quality: %d"),
			strOperator,nSignalPercentage);
	}

	CString			strMessage	= strData;

	strMessage	+= strInfo;

	if(pClass)
		pClass->AddLog(strMessage);
}

void CALLBACK NotifyCallback(DWORD dwCode,const void *lpData,DWORD cbData, DWORD dwParam)
{
}

// CRILSampleDlg dialog

CRILSampleDlg::CRILSampleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRILSampleDlg::IDD, pParent)
{
	m_hIcon 				= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_hRIL					= NULL;
	m_hSignalQualityResult	= NULL;
	m_hOperatorNameResult	= NULL;
}

void CRILSampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DATA, m_wndData);
}

BEGIN_MESSAGE_MAP(CRILSampleDlg, CDialog)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_COMMAND(ID_MENU_ABOUT, &CRILSampleDlg::OnMenuAbout)
END_MESSAGE_MAP()

// CRILSampleDlg message handlers

void CRILSampleDlg::AddLog(LPCTSTR lpszLog)
{
	CString		strText;

	m_wndData.GetWindowText(strText);

	if(strText.GetLength() > 0)
		strText	+=	TEXT("\r\n");

	strText	+= lpszLog;

	m_wndData.SetWindowText(strText);
}


BOOL CRILSampleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	SHMENUBARINFO info; 
	
	info.cbSize			= sizeof(info); 
	info.hwndParent		= m_hWnd; 
	info.dwFlags		= SHCMBF_HMENU | SHCMBF_HIDESIPBUTTON; 
	info.nToolBarId		= IDR_MENU; 
	info.hInstRes		= ::AfxGetInstanceHandle(); 
	info.nBmpId			= 0; 
	info.cBmpImages		= 0; 
	
	SHCreateMenuBar(&info);

	HRESULT	hr = RIL_Initialize(1,ResultCallback,NotifyCallback,
								RIL_NCLASS_ALL,(DWORD)this,&m_hRIL);

	if(FAILED(hr))
	{
		m_hRIL	= NULL;

		AfxMessageBox(TEXT("Failed to initialize RIL"));
	}
	else
	{
		m_hOperatorNameResult	= RIL_GetCurrentOperator(m_hRIL,RIL_OPFORMAT_LONG);
		m_hSignalQualityResult	= RIL_GetSignalQuality(m_hRIL); 

		if(FAILED(m_hSignalQualityResult) || FAILED(m_hOperatorNameResult))
		{
			CString		strError;

			strError.Format(TEXT("Error getting signal quality: %X"),m_hSignalQualityResult);

			AfxMessageBox(strError);
		}
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRILSampleDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType,cx,cy);

	if(m_wndData.GetSafeHwnd())
	{
		m_wndData.SetWindowPos(NULL,DRA::SCALEX(X_OFFSET),DRA::SCALEX(Y_OFFSET),
							   DRA::SCALEX(cx - X_OFFSET * 2),DRA::SCALEX(cy - X_OFFSET * 2),
							   SWP_NOZORDER);
	}
}

void CRILSampleDlg::OnDestroy()
{
	if(m_hRIL)
		RIL_Deinitialize(m_hRIL);

	CDialog::OnDestroy();
}

void CRILSampleDlg::OnMenuAbout()
{
	AfxMessageBox(TEXT("RIL Sample\r\nKrishnaraj Varma\r\nhttp://www.krvarma.com\r\nvarma@krvarma.com"));
}