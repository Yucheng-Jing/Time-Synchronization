// RILSampleDlg.h : header file
//

#pragma once
#include "afxwin.h"

#define X_OFFSET		10
#define Y_OFFSET		10

#define RIL_DEVSPECIFICPARAM_ENABLECELLIDSUPPORT	26
#define RIL_DEVSPECIFICPARAM_DISABLECELLIDSUPPORT	27 

// CRILSampleDlg dialog
class CRILSampleDlg : public CDialog
{
// Construction
public:
	CRILSampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_RILSAMPLE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

public:
	void AddLog(LPCTSTR lpszLog);

public:
	HRESULT GetSignalQualityResult() const
	{
		return m_hSignalQualityResult;
	}
	
	HRESULT GetOperatorNameResult() const
	{
		return m_hOperatorNameResult;
	}

	void SetCurrentOperator(char* lpszOperator)
	{
		m_strCurrentOperator	= lpszOperator;
	}

	LPCTSTR GetCurrentOperator()
	{
		return m_strCurrentOperator;
	}

private:
	HRIL		m_hRIL;
	HRESULT		m_hSignalQualityResult;
	HRESULT		m_hOperatorNameResult;
	CString		m_strCurrentOperator;
	CEdit		m_wndData;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT /*nType*/, int /*cx*/, int /*cy*/);
	afx_msg void OnMenuAbout();
	afx_msg void OnDestroy();

	DECLARE_MESSAGE_MAP()
};
